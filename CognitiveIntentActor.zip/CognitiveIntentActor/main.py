import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, List, Tuple

torch.set_default_dtype(torch.float32)
torch.manual_seed(42)


class CognitiveIntentActor(nn.Module):
    """Human-like cognitive agent that forms, enacts, and updates intentions."""

    def __init__(self, state_dim: int, intention_dim: int, hidden_dim: int = 64):
        super().__init__()
        self.state_dim = state_dim
        self.intention_dim = intention_dim

        self.intent_projector = nn.Sequential(
            nn.Linear(state_dim + intention_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, intention_dim),
        )
        self.policy = nn.Sequential(
            nn.Linear(intention_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, state_dim),
        )
        self.forward_model = nn.Sequential(
            nn.Linear(state_dim + intention_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, state_dim),
        )

        self.register_buffer("belief_state", torch.zeros(state_dim))
        self.register_buffer("prior_intent", torch.zeros(intention_dim))
        self.register_buffer("sensory_precision", torch.zeros(state_dim))
        self.register_buffer("current_intent", torch.zeros(intention_dim))
        self.register_buffer("last_action", torch.zeros(state_dim))

    def perceive(self, environment_state: torch.Tensor, regulation_feedback: torch.Tensor) -> torch.Tensor:
        precision = torch.sigmoid(self.sensory_precision)
        fused = precision * environment_state + (1.0 - precision) * regulation_feedback
        integrated = 0.7 * self.belief_state + 0.3 * fused
        self.belief_state = integrated
        return integrated

    def form_intention(self, perception: torch.Tensor) -> torch.Tensor:
        intent_input = torch.cat([perception, self.prior_intent], dim=0)
        update = torch.tanh(self.intent_projector(intent_input))
        self.current_intent = 0.6 * self.current_intent + 0.4 * update
        return self.current_intent

    def act(self, intent: torch.Tensor) -> torch.Tensor:
        action = torch.tanh(self.policy(intent))
        self.last_action = action
        return action

    def predict_outcome(self, action: torch.Tensor, intent: torch.Tensor) -> torch.Tensor:
        forward_input = torch.cat([action, intent], dim=0)
        return self.forward_model(forward_input)

    def integrate_feedback(
        self,
        prediction_error: torch.Tensor,
        intent_correction: torch.Tensor,
        state_feedback: torch.Tensor,
    ) -> None:
        self.belief_state = self.belief_state + 0.25 * prediction_error + 0.1 * state_feedback
        self.prior_intent = torch.tanh(self.prior_intent + 0.2 * intent_correction)
        self.sensory_precision = (self.sensory_precision + 0.05 * prediction_error).clamp(-2.0, 2.0)


class MachineRegulator(nn.Module):
    """Machine collaborator that infers intention and shapes feedback to the actor."""

    def __init__(self, state_dim: int, intention_dim: int, hidden_dim: int = 64):
        super().__init__()
        self.state_dim = state_dim
        self.intention_dim = intention_dim

        self.intent_decoder = nn.Sequential(
            nn.Linear(2 * state_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, intention_dim),
        )
        self.feedback_policy = nn.Sequential(
            nn.Linear(2 * intention_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, state_dim),
        )

        self.register_buffer("shared_goal", torch.tanh(torch.randn(intention_dim)))
        self.register_buffer("running_alignment", torch.zeros(1))

    def observe(self, actor_action: torch.Tensor, environment_state: torch.Tensor) -> torch.Tensor:
        return torch.cat([actor_action, environment_state], dim=0)

    def infer_intention(self, observation: torch.Tensor) -> torch.Tensor:
        inferred = torch.tanh(self.intent_decoder(observation))
        return inferred

    def generate_feedback(
        self,
        inferred_intent: torch.Tensor,
        environment_state: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, float]:
        alignment = F.cosine_similarity(inferred_intent, self.shared_goal, dim=0, eps=1e-6)
        self.running_alignment = 0.9 * self.running_alignment + 0.1 * alignment.unsqueeze(0)

        intent_error = self.shared_goal - inferred_intent
        intent_correction = torch.tanh(intent_error)

        policy_input = torch.cat([intent_correction, inferred_intent], dim=0)
        state_feedback = torch.tanh(self.feedback_policy(policy_input))
        regulation_gain = 0.3 + 0.4 * (1.0 - alignment.clamp(-1.0, 1.0))
        state_feedback = regulation_gain * state_feedback + 0.1 * environment_state

        return state_feedback, intent_correction, alignment.item()


class Environment:
    """Non-linear environment that couples to the actor through shared goals."""

    def __init__(self, state_dim: int):
        self.state_dim = state_dim
        self.transition = 0.55 * torch.eye(state_dim) + 0.25 * torch.randn(state_dim, state_dim)
        self.target_state = torch.tanh(torch.randn(state_dim))
        self.noise_scale = 0.04
        self.state = torch.zeros(state_dim)

    def reset(self) -> torch.Tensor:
        self.state = torch.randn(self.state_dim) * 0.05
        return self.state.clone()

    def step(self, action: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        drift = torch.tanh(self.transition @ action)
        self.state = 0.6 * self.state + 0.3 * drift + 0.1 * self.target_state
        self.state = self.state + torch.randn_like(self.state) * self.noise_scale
        environment_feedback = self.target_state - self.state
        return self.state.clone(), environment_feedback


def compute_prediction_error(observed_state: torch.Tensor, predicted_outcome: torch.Tensor) -> torch.Tensor:
    return observed_state - predicted_outcome


def compute_intentionality(
    intent: torch.Tensor,
    action: torch.Tensor,
    environment_state: torch.Tensor,
    shared_goal: torch.Tensor,
) -> Tuple[float, float, float]:
    goal_alignment = F.cosine_similarity(intent, shared_goal, dim=0, eps=1e-6).item()
    sensorimotor_coherence = F.cosine_similarity(action, environment_state, dim=0, eps=1e-6).item()
    intent_deviation = torch.mean((intent - shared_goal) ** 2).item()
    return goal_alignment, sensorimotor_coherence, intent_deviation


def summarize_history(history: Dict[str, List[float]]) -> Dict[str, Tuple[float, float]]:
    summary: Dict[str, Tuple[float, float]] = {}
    for key, values in history.items():
        series = torch.tensor(values)
        summary[key] = (series.mean().item(), series[-1].item())
    return summary


def run_simulation(
    state_dim: int = 12,
    intention_dim: int = 6,
    hidden_dim: int = 64,
    time_steps: int = 200,
) -> Dict[str, List[float]]:
    actor = CognitiveIntentActor(state_dim, intention_dim, hidden_dim)
    machine = MachineRegulator(state_dim, intention_dim, hidden_dim)
    environment = Environment(state_dim)

    environment_state = environment.reset()
    regulation_state = torch.zeros(state_dim)

    history: Dict[str, List[float]] = {
        "alignment": [],
        "coherence": [],
        "intent_error": [],
        "prediction_error": [],
        "machine_alignment": [],
    }

    for step in range(time_steps):
        perception = actor.perceive(environment_state, regulation_state)
        intent = actor.form_intention(perception)
        action = actor.act(intent)
        predicted_outcome = actor.predict_outcome(action, intent)

        environment_state, environment_feedback = environment.step(action)
        prediction_error = compute_prediction_error(environment_state, predicted_outcome)

        observation = machine.observe(action, environment_state)
        inferred_intent = machine.infer_intention(observation)
        regulation_state, intent_correction, machine_alignment = machine.generate_feedback(
            inferred_intent, environment_state
        )

        combined_feedback = regulation_state + environment_feedback
        actor.integrate_feedback(prediction_error, intent_correction, combined_feedback)

        goal_alignment, coherence, intent_deviation = compute_intentionality(
            intent, action, environment_state, machine.shared_goal
        )

        history["alignment"].append(goal_alignment)
        history["coherence"].append(coherence)
        history["intent_error"].append(intent_deviation)
        history["prediction_error"].append(prediction_error.norm().item())
        history["machine_alignment"].append(machine_alignment)

    return history


if __name__ == "__main__":
    simulation_history = run_simulation()
    stats = summarize_history(simulation_history)

    print("Simulation complete.")
    print(
        "Goal alignment mean -> final: "
        f"{stats['alignment'][0]:.3f} -> {stats['alignment'][1]:.3f}"
    )
    print(
        "Sensorimotor coherence mean -> final: "
        f"{stats['coherence'][0]:.3f} -> {stats['coherence'][1]:.3f}"
    )
    print(
        "Intent deviation mean -> final: "
        f"{stats['intent_error'][0]:.3f} -> {stats['intent_error'][1]:.3f}"
    )
    print(
        "Prediction error mean -> final: "
        f"{stats['prediction_error'][0]:.3f} -> {stats['prediction_error'][1]:.3f}"
    )
    print(
        "Machine alignment mean -> final: "
        f"{stats['machine_alignment'][0]:.3f} -> {stats['machine_alignment'][1]:.3f}"
    )
